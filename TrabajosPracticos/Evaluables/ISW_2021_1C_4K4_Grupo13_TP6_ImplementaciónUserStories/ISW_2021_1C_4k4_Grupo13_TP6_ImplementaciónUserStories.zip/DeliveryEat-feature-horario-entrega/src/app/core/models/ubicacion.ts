export class Ubicacion {
  id: number
  direccion: string
  numero: string
  ciudad: string
  referencias: string
  latitudPin: number = null
  longitudPin: number = null
}
