import { MedioPago } from './medio-pago'

describe('MedioPago', () => {
  it('should create an instance', () => {
    expect(new MedioPago()).toBeTruthy()
  })
})
