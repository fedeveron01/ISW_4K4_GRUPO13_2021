export class MedioPago {
  id: number
  tipo: string
  monto: string
  titular: string
}
