export class HorarioEntrega {
  id: number
  horario: string
  tipo: string
}
