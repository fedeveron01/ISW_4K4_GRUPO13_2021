import { HorarioEntrega } from './horario-entrega'

describe('HorarioEntrega', () => {
  it('should create an instance', () => {
    expect(new HorarioEntrega()).toBeTruthy()
  })
})
