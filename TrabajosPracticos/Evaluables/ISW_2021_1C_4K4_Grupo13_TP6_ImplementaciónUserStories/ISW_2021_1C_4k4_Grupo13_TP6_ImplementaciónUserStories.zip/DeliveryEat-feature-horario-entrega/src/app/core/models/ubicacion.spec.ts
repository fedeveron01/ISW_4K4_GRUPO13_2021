import { Ubicacion } from './ubicacion'

describe('Ubicacion', () => {
  it('should create an instance', () => {
    expect(new Ubicacion()).toBeTruthy()
  })
})
